<script>
import collectionMixin from '@/mixins/collection-mixin.vue'
import nftMixin from '@/mixins/nft-mixin.vue'
import db from '@/services/db'
export default {
  name: 'collection-item-list',
  mixins: [collectionMixin, nftMixin],
  methods: {
    async onRemoveNft(nft) {
      try {
        await this.removeNftFromCollection(
          this.collectionSelectedData.id,
          nft.id
        )
        this.$store.dispatch('setSnackbar', { show: true, text: 'nft removed' })
      } catch (e) {
        console.log(e)
      }
    },
    showNftDetailModal(nft) {
      this.$store.dispatch('setModalData', nft)
      this.$store.dispatch('toggleModal', 'nft-detailed')
    },
  },
  async mounted() {
    console.log('collection-item-list mounted')
    if (this?.collectionSelectedItems?.length > 0) {
      const items = []
      for (let item of this.collectionSelectedItems) {
        const itemData = await db.get('nfts', item)
        items.push(itemData)
      }
      this.$store.dispatch('setCollectionItemsData', items)
    }
  },
}
</script>
<template>
  <div>
    <nft-card-collection
      v-for="nft in collectionItemsData"
      :key="nft.id"
      :nft="nft"
      @addNftToCollection="addNftToCollection"
      @removeNftFromCollection="onRemoveNft"
      @showDetails="showNftDetailModal"
    ></nft-card-collection>
  </div>
</template>

<style lang="scss" scoped></style>
