<script>
import Navigation from '@/components/navigation.vue'
import WalletButton from '@/components/wallet-button.vue'
export default {
  name: 'header-main',
  components: {
    Navigation,
    WalletButton,
  },
}
</script>

<template>
  <header class="header">
    <section class="header-section flex-row full-width">
      <a href="/" class="flex-row title">
        <img class="logo" src="/kirby-icon.png" />
        <!-- <i class="nes-icon reddit is-large"></i> -->
        <h1 class="title-text">NFTy-Trckr</h1>
      </a>
      <section class="navigation">
        <navigation>
          <!-- v-if="$store.state.documentScrollPos >= 65" -->
          <wallet-button
            v-if="$route.name !== 'index'"
            :withText="false"
          ></wallet-button
        ></navigation>
      </section>
    </section>
    <!-- v-if="$store.state.documentScrollPos < 65" -->
    <section
      v-if="$route.name === 'index'"
      class="wallet-section flex-row full-width"
    >
      <wallet-button></wallet-button>
    </section>
  </header>
</template>
<style scoped>
header {
  padding: 0.5rem;
  position: sticky;
  position: -webkit-sticky;
  top: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-between;
  background-color: var(--background-color);
  z-index: 5;
}

.title {
  white-space: nowrap;
  flex-wrap: wrap;
  text-decoration: none;
}

.title-text {
  /* margin-left: var(--base-padding); */
  margin-bottom: 0;
  background: #f2b310;
  color: transparent;
  background-clip: text;
  background: linear-gradient(
    to right,
    #f23900 0%,
    #f2b310 50%,
    #097c78 85%,
    #209cee 100%
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.title-text:hover {
  margin-bottom: 0;
  background: #f2b310;
  color: transparent;
  background-clip: text;
  background: linear-gradient(
      to right,
      #f23900 0%,
      #f2b310 50%,
      #097c78 85%,
      #209cee 100%
    )
    0 0 / 400% 100%;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: move-bg 8s linear infinite;
}

.header-section {
  flex-wrap: wrap;
  justify-content: space-between;
  /* height: var(--header-height); */
  flex-shrink: 1;
}

.logo {
  height: 5rem;
  width: 5.75rem;
  margin-left: -20px;
}
.navigation {
  padding-bottom: 0.2rem;
  text-align: start;
}

.wallet-section {
  justify-content: flex-end;
  padding-bottom: 1rem;
}

@media screen and (max-width: 700px) {
  .wallet-section {
    justify-content: flex-start;
  }
}

@keyframes move-bg {
  to {
    background-position: 400% 0;
  }
}
</style>
