<script>
export default {
  name: 'navigation',
  methods: {
    onNav() {
      //If on current route, set view to default
      this.$store.dispatch('setView', null)
    },
  },
}
</script>
<template>
  <nav class="nav-wrapper">
    <NuxtLink to="/" exact>
      <img src="/pipe-top.png" alt="" class="nav-icon" />
    </NuxtLink>
    <NuxtLink
      to="/collections"
      class="nes-text nav-link"
      active-class="is-primary nav-link-active"
      @click.native="onNav"
      >Collections
    </NuxtLink>
    |
    <NuxtLink
      to="/tracker"
      class="nes-text nav-link"
      active-class="is-primary nav-link-active"
    >
      Tracker</NuxtLink
    >
    <slot></slot>
  </nav>
</template>
<style lang="css" scoped>
.nav-wrapper {
  display: flex;
  flex-grow: 1;
  align-items: center;
  justify-content: flex-end;
}

.nav-icon {
  height: 1.75rem;
  width: 1.75rem;
  margin-bottom: 0.25rem;
}

.nav-link {
  color: #fff;
  padding-inline: 0.75rem;
}

.nav-link-active {
  text-decoration: underline;
  color: #209cee;
}
</style>
