<script>
import { mapGetters, mapState } from 'vuex'
import ListStats from '@/components/list-stats.vue'

import collectionMixin from '@/mixins/collection-mixin.vue'
import nftMixin from '@/mixins/nft-mixin.vue'

import api from '@/services/api.js'
import db from '@/services/db.js'
import utils from '@/services/utils.js'
import loopring from '@/services/loopring'
export default {
  name: 'header-collections',
  components: {
    ListStats,
  },
  mixins: [collectionMixin, nftMixin],
  data: () => ({
    showFilters: false,
  }),
  computed: {
    ...mapState({
      collections: (state) => state.collections,
      defaultCollections: (state) => state.defaultCollections,
      collectionSelectedData: (state) => state.collectionSelectedData,
      collectionsHeader: (state) => state.collectionsHeader,
      connectedWallet: (state) => state.connectedWallet,
      contentLoading: (state) => state.contentLoading,
      filters: (state) => state.collectionsHeader.filters,
      subView: (state) => state.subView,
      view: (state) => state.view,
    }),
    addDisabled() {
      return (
        !this.view ||
        this.view !== 'all' ||
        (this.view === 'collection' && this.collectionSelectedData?.isCustom)
      )
    },
    collectionSelect: {
      get() {
        return this.collectionsHeader.collectionSelect
      },
      set(v) {
        this.updateCollectionsHeader({ collectionSelect: v })
      },
    },
    hasFilters() {
      return Object.values(this.filters).filter((f) => f).length > 0
    },
    radioNav: {
      get() {
        return this.$store.state.subView
      },
      set(v) {
        console.log(v)
        this.$router.push({ path: `/collections/${v}` })
        // this.$store.dispatch('setView', v)
      },
    },
    refreshDisabled() {
      return this.view === 'all' || this.collectionSelect === 'select'
    },
    searchInput: {
      get() {
        return this.filters.search
      },
      set(v) {
        this.updateCollectionsHeader({
          filters: { ...this.filters, search: v },
        })
      },
    },
    sortSelect: {
      get() {
        return this.collectionsHeader.sortSelect
      },
      set(v) {
        this.updateCollectionsHeader({ sortSelect: v })
      },
    },
  },
  methods: {
    test() {
      loopring.test()
      this.$store.dispatch('toggleModal', 'collection-edit')
    },
    cacheTime(time_utc) {
      return utils.epochToHuman(time_utc)
    },
    messageText() {
      if (!this.view) return 'Select an option above.'
      if (this.subView === 'all') return 'Collection Library'
      if (this.view === 'collection' && !this.collectionSelectedData?.id)
        return 'No collection selected.'
      if (this.collectionSelectedData?.name)
        return this.collectionSelectedData.name
      return ''
    },
    onCollectionSelect({ target }) {
      // console.log(target)
      // console.log(this.collectionSelect)
      // this.$store.dispatch(
      //   'setCollectionSelectedDataByCollectionId',
      //   target.value
      // )

      // replace below.. if collectionSelectedData.items < 1... auto get?
      return
      // this.$store.dispatch('setContentLoading', true)
      // this.$store.dispatch('setCollectionSelectedData', [])
      // if (target.value === 'nifty') {
      //   const niftyLocal = db.get('nifty', 'collection')
      //   if (niftyLocal) {
      //     this.$store.dispatch('setCollectionSelectedData', niftyLocal)
      //     this.$store.dispatch('setContentLoading', false)
      //     return
      //   }
      //   await this.refreshCollectionSelectedData()
      // }

      // // next: is the below correct?
      // const value =
      //   target.value === 'connected' ? this.connectedWallet : target.value
      // this.$store.dispatch('setCollectionSelectedDataByCollectionId', value)
      // this.$store.dispatch('setContentLoading', false)
    },
    async refreshCollectionSelectedData() {
      console.log('TODO: REFACTOR')
      // if (this.collectionSelect === 'select') return
      if (!this.collectionSelect || this.collectionSelect === 'select') return //set error
      this.$store.dispatch('setContentLoading', true)
      this.$store.dispatch('setCollectionSelectedData', {
        items: [],
      })
      const niftyCollection = this.defaultCollections.filter(
        (c) => c.value === 'nifty'
      )[0]
      if (this.collectionSelect === niftyCollection.id) {
        //
        // TODO MOVE THIS INTO SEPARATE FUNCTION
        //
        const niftys = await api.getNiftyGames()
        for (let nifty of niftys) {
          const nft = await api.getNftInfoByNftData(nifty.nftData, true)
          const nftFixed = this.normalizeNft(nft)
          console.log(this.collectionSelectedData)
          this.$store.dispatch('setCollectionSelectedData', {
            ...this.collectionSelectedData,
            items: [...this.collectionSelectedData.items, nftFixed],
          })
        }
        console.log('PICK UP HERE <====')
        //  PICK UP HERE, update cachedate, itemCount, etc
        // this.$store.dispatch('saveCollection', )

        db.write(
          this.collectionSelectedData.id,
          this.collectionSelectedData.items
        )
        // db.savecollectionSelectedData('nifty', this.collectionSelectedData.items)
        console.log(
          'pick up here, update collection cached date, save collections and collection'
        )
        db.write(
          this.collectionSelectedData.id,
          this.collectionSelectedData.items
        )
      } else {
      }
      this.$store.dispatch('setContentLoading', false)
    },
    sortOptionText(option) {
      return option.split('_').join(' ')
    },
    toggleFilters() {
      this.updateCollectionsHeader({ filters: { show: !this.filters.show } })
    },
  },
  created() {
    console.log(this.$route)
    // const view = this?.$route?.params?.view
    // console.log(view)
    // if (!view) return
    // if (view === 'all' || view === 'collection') this.view = view
    // else {
    //   const foundCollection = this.collections.find((c) => c.id === view)
    //   console.log(this.collections)
    //   console.log(this.foundCollection)
    //   console.log(view)
    //   if (foundCollection) {
    //     this.$store.dispatch('setCollectionSelectedData', foundCollection)
    //   }
    // }
  },
}
</script>
<template>
  <section class="page-header pa">
    <article
      class="main-section flex-column nes-container is-rounded with-title full-width"
    >
      <div class="top-section flex-row full-width">
        <label
          class="nes-text mr"
          :class="`is-${radioNav === 'all' ? 'primary' : ''}`"
        >
          <input
            v-model="radioNav"
            value="all"
            type="radio"
            class="nes-radio"
            name="radio-collection"
          />
          <span>All</span>
        </label>
        <label
          class="nes-text mr"
          :class="`is-${radioNav === 'collection' ? 'primary' : ''}`"
        >
          <input
            v-model="radioNav"
            value="collection"
            type="radio"
            class="nes-radio"
            name="radio-collection"
          />
          <span>Collection</span>
        </label>
        <label
          class="nes-text ml-auto"
          :class="`is-${
            hasFilters ? 'success' : radioNav === 'filters' ? 'primary' : ''
          }`"
        >
          <input
            v-model="showFilters"
            name="enable-filters"
            type="checkbox"
            class="nes-checkbox is-dark"
            :class="`is-${
              hasFilters ? 'success' : radioNav === 'filters' ? 'primary' : ''
            }`"
          />
          <span>Filters</span>
        </label>
      </div>

      <div class="bottom-section flex-row full-width">
        <div v-if="!showFilters" class="flex-row flex-end full-width">
          <div>
            <p class="nes-text is-primary">
              {{ messageText() }}
            </p>
            <ListStats
              :selectedData="collectionSelectedData"
              :selectedItems="collectionItemsDisplayed"
              :selectedItemsDisplayed="collectionItemsDisplayed"
            />
          </div>
          <div class="bottom-btns flex-row">
            <button
              :disabled="refreshDisabled"
              title="Refresh collection data from blockchain."
              class="action-btn nes-btn"
              :class="refreshDisabled ? 'is-disabled' : 'is-success'"
              @click="!contentLoading ? refreshCollectionSelectedData() : null"
            >
              <img
                src="/refresh-icon.png"
                class="refresh-icon"
                :class="{ rotate: contentLoading }"
              />
            </button>
            <button
              :disabled="addDisabled"
              :title="
                radioNav === 'all'
                  ? 'Add new collection.'
                  : 'Add a new nft to the selected collection.'
              "
              class="action-btn nes-btn ml"
              :class="addDisabled ? 'is-disabled' : 'is-success'"
              @click="test"
            >
              &#43;
            </button>
          </div>
        </div>
        <div v-else class="filters-section full-width flex-row">
          <div class="filters-section-side">
            <label for="search-input">Search</label>
            <div class="nes-field">
              <input
                v-model="searchInput"
                type="text"
                id="search-input"
                class="nes-input is-dark"
              />
            </div>
          </div>
          <div class="filters-section-side">
            <label for="sort-select">Sort by</label>
            <div class="nes-select">
              <select required id="sort-select" v-model="sortSelect">
                <option
                  v-for="option in collectionsHeader.sortSelectOptions"
                  :key="option.value"
                  :value="option.value"
                  :disabled="option.disabled"
                  :selected="option.value === collectionSelect"
                  :hidden="option.hidden"
                >
                  {{ option.text }}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- <div
        v-if="view === 'collection'"
        class="collection-select flex-row full-width"
      >
        <div class="full-width">
          <div class="nes-select">
          <CollectionSelect/>
          </div>
        </div>
      </div> -->
    </article>
  </section>
</template>
<style lang="css" scoped>
.page-header {
  position: sticky;
  top: var(--header-height);
  padding-bottom: 1rem;
  padding-top: 0px;
  z-index: 5;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background-color: var(--background-color);
}

.main-section {
  padding: 1rem;
  align-items: flex-start;
  justify-content: space-between;
}

.top-section {
  align-items: flex-start;
  justify-items: flex-start;
}

.filter-radio {
  margin-left: 1rem;
}

.nes-radio:checked + span::before {
  color: var(--primary-color);
}

.bottom-btns {
  align-items: flex-end;
  margin-left: auto;
}

.top-btns {
  margin-left: auto;
}

.collection-select {
  align-items: center;
  /* display: flex; */
  margin-top: 2rem;
}

.add-collection-btn {
  /* padding: 0.5rem; */
  margin-left: 1.5rem;
}

.bottom-section {
  padding-top: 1rem;
  justify-content: space-between;
  align-items: flex-end;
  min-height: 120px;
}

.filters-btn {
  display: flex;
  align-items: flex-start;
  padding-inline: 0.5rem;
}

.filters-btn-icon {
  text-shadow: 1px 1px #212529;
}

.filters-section {
  justify-content: space-between;
  min-height: 120px;
}

.filters-section-side {
  width: 48%;
}
</style>
