<script>
import DetailCard from '@/components/detail-card.vue'
import Loader from '@/components/loader.vue'
import Modal from '@/components/modal.vue'

import nftMixin from '@/mixins/nft-mixin.vue'

export default {
  name: 'nft-detailed',
  components: {
    DetailCard,
    Loader,
    Modal,
  },
  mixins: [nftMixin],
  data: () => ({
    details: [
      {
        name: 'createdAtHuman',
        label: 'Created',
      },
      {
        name: 'tokenAddress',
        label: 'Token Address',
      },
      {
        name: 'nftId',
        label: 'NFT ID',
      },
      {
        name: 'nftType',
        label: 'Type',
      },
      {
        name: 'nftData',
        label: 'NFT Data',
      },

      {
        name: 'creatorFeeBips',
        label: 'Creator Fee Bips',
      },
      {
        name: 'minter',
        label: 'Minter',
      },
      {
        name: 'originalMinter',
        label: 'Original Minter',
      },
      {
        name: 'nftBaseUri',
        label: 'Base Uri',
      },

      {
        name: 'nftFactory',
        label: 'NFT Factory',
      },

      {
        name: 'nftOwner',
        label: 'Owner',
      },
      {
        name: 'royaltyAddress',
        label: 'Royalty Address',
      },
      {
        name: 'royaltyPercentage',
        label: 'Royalty %',
      },
      {
        name: 'status',
        label: 'Status',
      },
    ],
    detailView: 'description',
    holdersLoading: true,
    imgLoading: true,
    nftHolders: [],
    nftHoldersCount: null,
  }),
  computed: {
    nft() {
      return this.$store.state.modalData || {}
    },
    detailSectionHeight() {
      return '200px'
    },
    displayedImage() {
      return this.nft?.metadata?.animation || this.nft?.metadata?.image || ''
    },
  },
  methods: {
    setDetailHeight() {
      const modalHeight = this.$refs?.modal?.$el?.firstChild?.offsetHeight || 0
      //margin/paddding, title, radio row, image container,
      const contentOffset =
        80 + 50 + 50 + this.$refs?.imageContainer?.offsetHeight || 0
      console.log(modalHeight)
      console.log(this.$refs?.imageContainer?.offsetHeight)
      console.log(contentOffset)
      const height = modalHeight - contentOffset
      this.$refs.detailSection.style.height = height + 'px'
      return height
    },
    async setIframeDimensions() {
      if (!this.displayedImage) return
      const img = new Image()
      img.src = this.displayedImage
      const imageContainer = this.$refs.imageContainer
      const maxHeight = 400
      const maxWidth = 400

      img.onload = (e) => {
        if (
          e?.target &&
          e.target.height < maxHeight &&
          e.target.width < maxWidth
        ) {
          imageContainer.style.height = e.target.height + 'px'
          imageContainer.style.width = e.target.width + 'px'
        }
        this.$nextTick(this.setDetailHeight)
      }
    },
    trimDetail(detail = '') {
      const detailLength = detail.length || 0
      if (detailLength > 10) {
        return `${detail.substring(0, 6)}...${detail.substring(
          detailLength - 6
        )}`
      }
      return detail
    },
  },
  async mounted() {
    console.log('modal mounted')
    this.setIframeDimensions()
    const { nftHolders, totalNum } = this.getNftHolders(this.nft.nftData)
    if (nftHolders && totalNum) {
      this.nftHolders = nftHolders
      this.nftHoldersCount = totalNum
    }
    //todo setup pagination, lazy loading
  },
}
</script>
<template>
  <modal ref="modal" :isOpen="$store.state.modal === 'nft-detailed'">
    <div class="card" @click.stop="">
      <h2 class="title nes-text is-primary">
        {{ nft.metadata?.name || 'NFT DETAILS' }}
      </h2>

      <section ref="imageContainer" class="image-container">
        <!-- src="https://loopring.mypinata.cloud/ipfs/QmQ9htoCZ7Vr6JArpq6HtnvszghmyKEx16AYgq5PqGXj7y/?filename=src" -->

        <!-- detect image size and adjust -->
        <!-- https://www.dyn-web.com/tutorials/iframes/height/ -->

        <!-- <p v-if="displayedImage" class="image-loading">loading...</p> -->
        <iframe
          :src="displayedImage"
          class="image-iframe"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
          sandbox="allow-scripts allow-same-origin allow-storage-access-by-user-activation"
          frameborder="0"
        ></iframe>
        <!-- <img :src="" alt="preview image of nft" /> -->
      </section>
      <div class="radio-row flex-row full-width">
        <label
          class="nes-text mr"
          :class="`is-${detailView === 'description' ? 'primary' : ''}`"
        >
          <input
            v-model="detailView"
            value="description"
            type="radio"
            class="nes-radio is-dark"
            name="answer-dark"
          />
          <span>Description</span>
        </label>

        <label
          class="nes-text mr"
          :class="`is-${detailView === 'details' ? 'primary' : ''}`"
        >
          <input
            v-model="detailView"
            value="details"
            type="radio"
            class="nes-radio is-dark filter-radio"
            name="answer-dark"
          />
          <span>Details</span>
        </label>
        <label
          class="nes-text mr"
          :class="`is-${detailView === 'holders' ? 'primary' : ''}`"
        >
          <input
            v-model="detailView"
            value="holders"
            type="radio"
            class="nes-radio is-dark filter-radio"
            name="answer-dark"
          />
          <span>Hodlers</span>
        </label>
      </div>
      <article
        ref="detailSection"
        class="details-section flex-row full-width"
        :style="{ height: detailSectionHeight }"
      >
        <template v-if="detailView === 'description'">
          <p class="description-text">{{ nft?.metadata?.description || '' }}</p>
        </template>
        <template v-if="detailView === 'details'">
          <DetailCard
            v-for="detail in details"
            :key="detail.name"
            :detail="{ detail: detail.label, value: nft[detail.name] || '-' }"
          ></DetailCard>
        </template>
        <template v-if="detailView === 'holders'">
          <loader v-if="holdersLoading" class="loader"></loader>
          <!-- pickup here, display holders count (keep track of count pagination, > count > 500 ? "count+" : "count"), list -->
        </template>
      </article>
    </div>
  </modal>
</template>

<style lang="css" scoped>
.nes-radio.is-dark + span {
  /* color: #fff; */
  color: unset;
}

.card {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  height: 90vh;
  width: 80vw;
}
.image-container {
  height: 400px;
  width: 400px;
  box-sizing: border-box;
  margin-block: 1rem;
  padding: 0.5rem;
  display: flex;
  justify-items: center;
  border: 0.1rem;
  border-style: solid;
  border-color: #fff;
}

.image-loading {
  position: absolute;
  z-index: -1;
}

.image-iframe {
  height: 100%;
  width: 100%;
}

.radio-row {
  justify-content: center;
  max-width: 50rem;
}

.details-section {
  justify-content: space-between;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  font-size: 0.75rem;
  padding-inline: 2rem;
  margin-top: 1rem;
  height: calc(100% - 600px);
  width: 100%;
  overflow-y: auto;
}
/* .detail-column {
  height: 100%;
}

.detail-row {
  align-content: center;
  justify-content: space-between;
} */
</style>
