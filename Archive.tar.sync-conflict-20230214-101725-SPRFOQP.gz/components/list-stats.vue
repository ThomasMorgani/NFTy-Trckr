<script>
import CollectionMixin from '@/mixins/collection-mixin.vue'
export default {
  name: 'list-stats',
  mixins: [CollectionMixin],
  computed: {
    cachedText() {
      if (this.view === 'collections') {
        if (this.subView === 'all') {
          return '-'
        }
        if (this.subView === 'collection') {
          if (this?.$route?.params?.id) {
            return this.collectionSelectedData?.updated_at || '-'
          }
          return '-'
        }
      }
      //  collectionSelectedData?.cached_utc
      // ? cacheTime(collectionSelectedData.cached_utc)
      // : '-'
      return '-'
    },
    itemsText() {
      //  `${collectionSelectedItemsDisplayed?.length || 0} / ${
      //     collectionSelectedItems?.length || 0
      return `0 / 0`
    },
    subView() {
      return this.$store.state.subView || ''
    },
    view() {
      return this.$store.state.view || ''
    },
  },
  created() {
    console.log(this.$nuxt)
  },
}
</script>

<template>
  <div class="stats">
    <h6 class="displayed-count-text">
      cached:
      {{ cachedText }}
    </h6>
    <h6 class="displayed-count-text">
      displayed items:
      {{ itemsText }}
    </h6>
  </div>
</template>
<style lang="css" scoped>
.stats {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-between;

  width: 100%;
}
</style>
