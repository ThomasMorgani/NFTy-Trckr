<template>
  <div class="welcome-container flex-column">
    <h2 class="title">Collections</h2>
    <img src="/pokedex.png" alt="" />
    <article class="nes-container full-width is-dark is-centered with-title">
      <p>Organize NFTs into custom distribution groups.</p>
      <p>
        The tracker will use these collections to determine each wallet's
        history, ownership and status.
      </p>
    </article>
  </div>
</template>

<script>
export default {
  name: 'collections-welcome',
}
</script>

<style lang="css" scoped>
.welcome-container {
  height: 100%;
  justify-content: space-around;
}

.welcome-container img {
  width: 150px;
  margin-bottom: 2rem;
}
</style>
