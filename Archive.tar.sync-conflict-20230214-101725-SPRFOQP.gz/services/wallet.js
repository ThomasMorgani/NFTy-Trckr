import api from './api.js'

export default {
  async connectedWallets() {
    console.log('connectedWallets')
    if (!window.ethereum) return []
    const ethereum = window.ethereum
    const accounts = await ethereum.request({
      method: 'eth_accounts',
    })
    return accounts
  },
  async connectWallet() {
    // const ethereum = window.ethereum
    const ethereum = window.gamestop
    console.log(ethereum)
    if (!ethereum) {
      return false
    }
    try {
      const accounts = await ethereum.request({
        method: 'eth_requestAccounts',
      }) // <<< ask for permission

      console.log('connected')
      ethereum.on('disconnect', (message) =>
        console.log('WALLET DIS:' + message)
      )
      ethereum.on('message', (message) =>
        console.log('WALLET EVENT:' + message)
      )
      console.log(ethereum)
      console.log(accounts)
      return accounts[0] //always returns responding wallet
    } catch (e) {
      console.error('error connecting wallet')
      return e
    }
    // }
    console.log('wallet already connected')
    return ethereum.currentAddress
  },
  async isConnected() {
    if (!window?.ethereum?.connected) return false
    const ethereum = window.ethereum
    const accounts = await ethereum.request({
      method: 'eth_accounts',
    })
    return accounts.length > 0
  },
}
