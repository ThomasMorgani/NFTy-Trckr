import axios from 'axios'
import axiosThrottle from 'axios-request-throttle'

axiosThrottle.use(axios, { requestsPerSecond: 3 })
// import LoopringAPI from '@loopring-web/loopring-sdk'

// import account from '../private/keys.json'

import etherscan from '../private/etherscan.json'
import moralis from '../private/moralis.json'

import tempNifty from '../static/data/nifty_mappings.json'

import loopring from './loopring'
const account = {}

const LOOPRING_PINATA_URL = 'https://loopring.mypinata.cloud/ipfs'
const LOOPRING_URL = 'https://api3.loopring.io/api/v3'
const MORALIS_URL = 'https://deep-index.moralis.io/api/v2'
const RARIBLE_URL = 'https://api.rarible.org/v0.1'

const etherscanOptions = {
  params: {
    apikey: etherscan.apikey || null,
  },
}
const loopringOptions = {
  headers: {
    Accept: 'text/plain',
    common: {
      Accept: 'text/plain',
      'X-API-KEY': account?.ApiKey || null,
      // 'X-API-SIG': '',
    },
  },
}

const moralisOptions = {
  headers: {
    common: {
      'X-API-KEY': moralis?.web3ApiKey || null,
    },
  },
}

export default {
  logLoopSDK() {
    loopring.test()
  },
  async getAccountApiKey(accountId, sig) {
    const url = LOOPRING_URL + '/apiKey?accountId=' + accountId
    console.log(accountId, sig)
    const resp = await axios.get(url, { headers: { 'X-API-SIG': sig } })
    const apiKey = resp.data
    console.log(apiKey)
    return apiKey
  },
  async getAccountByWalletAddress(wallet) {
    //temp prev connection errors
    //temp handle ens
    console.log(wallet)

    if (!wallet || wallet.includes('.')) return null
    const accountUrl = LOOPRING_URL + '/account'
    try {
      const accountResult = await axios.get(accountUrl, {
        ...loopringOptions,
        params: { owner: wallet },
      })
      // const { accountId } = accountResult.data
      return accountResult.data || null
    } catch (e) {
      const resp = {
        error: true,
        message: 'error retrieving account.',
      }

      // reserve for other scenarios
      if (e?.data?.resultInfo?.message) {
        resp.message = e?.data?.resultInfo?.message
      }
      return resp
    }
  },
  async getAccountInfo(accountId = null, walletAddress = null) {
    const url = LOOPRING_URL + '/account'
    const params = {}
    if (accountId !== null) params.account = accountId
    if (walletAddress !== null) params.owner = walletAddress
    try {
      const resp = await axios.get(url, { params })
      return resp.data || null
    } catch (e) {
      throw e
      return e.response.data
    }
  },
  async getNftData(minter, tokenAddress, nftId, withMetadata = true) {
    const url = LOOPRING_URL + '/nft/info/nftData'
    const params = {
      minter,
      tokenAddress,
      nftId,
    }
    const { data } = await axios.get(url, { ...loopringOptions, params })
    console.log(data)
    if (withMetadata && data.nftId) {
      data.metadata = await this.getNftMetaDataBynftId(data.nftId)
    }
    return data
  },
  async getNftHolders(nftData) {
    if (typeof nftData !== 'string') return []
    const url = LOOPRING_URL + '/nft/info/nftHolders'
    const params = { nftData, limit: 100 }
    // const params = { nftData, limit: 500 }
    const resp = await axios.get(url, { ...loopringOptions, params })
    console.log(resp)
    return resp.data
  },
  async getNftInfoByNftData(nftDatas, withMetadata = false) {
    //pickup here, add method or just w/meta data
    //get info, get cid, get metadat

    if (!nftDatas) return null
    const url = LOOPRING_URL + '/nft/info/nfts'
    const params = { nftDatas, metadata: true }
    console.log({ ...loopringOptions, params })
    const resp = await axios.get(url, { ...loopringOptions, params })
    const nftInfo = resp.data[0]
    if (withMetadata && nftInfo.nftId) {
      nftInfo.metadata = await this.getNftMetaDataBynftId(nftInfo.nftId)
    }
    console.log(nftInfo)
    return nftInfo
  },
  // async getNftInfoByNftDatas(nftDatas) {
  //   console.log(nftDatas)
  //   if (!nftDatas) return []
  //   const nftInfoUrl = LOOPRING_URL + '/nft/info/nfts'
  //   console.log(nftInfoUrl)

  //   try {
  //     const nftInfoResult = await axios.get(nftInfoUrl, {
  //       ...loopringOptions,
  //       params: { nftDatas },
  //     })
  //     console.log(nftInfoResult)
  //     const nft = nftInfoResult.data[0]
  //     const test = await utils.getContractNFTMeta(
  //       nft.nftAddress,
  //       nft.nftId,
  //       nft.nftType
  //     )
  //     return nftInfoResult.data
  //   } catch (e) {
  //     console.log(e.message || 'no message property')
  //     console.log(e)
  //   }
  // },
  async getNftMetaDataBynftId(nftId) {
    console.log(nftId)
    const CID = await loopring.ipfsCIDfromnftId(nftId)
    const metadata = await this.getNftMetaDataByCID(CID)
    return metadata
  },
  async getNftMetaDataByCID(cid) {
    const resp = await axios.get(LOOPRING_PINATA_URL + '/' + cid, {
      headers: {
        Accept: 'text/plain',
      },
    })
    return resp.data
  },
  async getNftMetaDataByIdMoralis(nftId) {
    // nftId = '0xe021f036eb12ea0e2f099d9b72a5501edc79cc7f-0-0xe61286c57cefd61aa5752fb84ae251d54bab36fc-0x90e414e66ccbf567206ffef4c62bb2c95bfa8ae5f38ced79e6a47f2c4622cc11-10"'
    // nftId = '0x7de3085b3190b3a787822ee16f23be010f5f8686'
    // nftId = '0x90e414e66ccbf567206ffef4c62bb2c95bfa8ae5f38ced79e6a47f2c4622cc11'
    const url = MORALIS_URL + `/nft/${nftId}/1?chain=eth&format=decimal`
    // const url = MORALIS_URL + 'https://deep-index.moralis.io/api/v2/nft/0x7dE3085b3190B3a787822Ee16F23be010f5F8686/metadata?chain=eth'
    const resp = await axios.get(url, moralisOptions)
    console.log(resp)
    return resp.data
  },
  async getNiftyGames() {
    const resp = await axios.get(
      'https://beyourownarcade.com/wp-json/wp/v2/posts',
      { params: { categories: [58], per_page: 99 } }
    )
    const posts = resp.data || []
    //TODO ONCE nftId IS INCORPORATED INTO NIFTY ARCADE REMOVE FITLER, MAPPING
    const temp = posts
      .map((p) => ({
        date_gmt: p.date_gmt,
        excerpt: p.excerpt?.rendered || '',
        image: p?.yoast_head_json?.og_image?.[0]?.url || null,
        link: p.link,
        nftData: tempNifty[p.slug] || null,
        slug: p.slug,
        title: p?.title?.rendered || 'unknown title',
      }))
      .filter((p) => p.nftData !== null)
    return temp
  },
  async getNftTokenAddress({ nftFactory, nftOwner, nftBaseUri }) {
    const url = LOOPRING_URL + '/nft/info/computeTokenAddress'
    const params = {
      nftFactory,
      nftOwner,
      nftBaseUri,
    }
    const address = await axios.get(url, { params })
    return address.data
  },
  getUserNftBalancesLoopring: async (accountId, metadata = true) => {
    if (!accountId) return []
    const balancesUrl = LOOPRING_URL + '/user/nft/balances'
    console.log(accountId)

    try {
      let balances = []
      let limit = 50 //seems to be most api will return per request
      let offset = 0
      const initialResult = await axios.get(balancesUrl, {
        ...loopringOptions,
        params: {
          accountId,
          metadata,
          minter: true,
          nftdata: true,
          nft: true,
          nftminter: true,
          limit,
          offset,
        },
      })
      let totalRemain = initialResult.data.totalNum || 0
      balances = [...initialResult.data.data]
      while (totalRemain > 0) {
        offset += totalRemain >= limit ? limit : totalRemain
        const resp = await axios.get(balancesUrl, {
          ...loopringOptions,
          params: { accountId, metadata, limit, offset },
        })
        console.log(resp)
        balances = [...balances, ...resp.data.data]
        console.log(balances)
        console.log(totalRemain)
        totalRemain -= offset
        console.log(totalRemain)
      }
      return balances
      // console.log(balanceResult)
      // return balanceResult.data.data
    } catch (e) {
      console.log(e.message || 'no message property')
      console.log(e)
    }
  },
  getUserNftBalancesMoralis: async (walletAddress) => {
    if (!walletAddress) return null
    const url = `${MORALIS_URL}/${walletAddress}/nft?chain=eth&format=decimal`
    const res = await axios.get(url, moralisOptions)
    console.log(res)
  },
  getUserNftBalancesRarible: async (wallet) => {
    //https://api.rarible.org/v0.1/items/byOwner/?owner=ETHEREUM:0xA62C40b4c3A08BA9da949398F3208DCD0922F215
    // const url = 'https://api.rarible.org/v0.1/items/byOwner/'
    const url = RARIBLE_URL + '/activities/byUser/'
    const params = {
      blockchains: [
        'ETHEREUM',
        'POLYGON',
        'FLOW',
        'TEZOS',
        'SOLANA',
        'IMMUTABLEX',
      ],
      // blockchains: 'ETHEREUM',
      type: 'TRANSFER_TO', //TO DO, CHANGE THIS
      user: `ETHEREUM:${wallet}`,
    }
    const resp = await axios.get(url, { params })
    console.log(resp)
    return resp
  },
  getReddit: async (url) => {
    // const url =
    //   'https://api.reddit.com/r/GamestopNFTGames/comments/vg1tf7/its_time_for_another_nft_minigame_giveaway_drop/'
    const res = await axios.get(url)
    // console.log(res)
    return res.data
  },
}
