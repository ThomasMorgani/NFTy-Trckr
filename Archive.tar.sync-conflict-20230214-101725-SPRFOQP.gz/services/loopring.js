import * as sdk from '@loopring-web/loopring-sdk'
import api from '@/services/api'
export default {
  test() {
    console.log(sdk)
  },

  async getApiKey(account) {
    /*
        working methods:
          eth_chainId
      */
    if (!account) return
    const { owner: wallet } = account
    console.log('-----TESTING----')
    const ethereum = window.gamestop || window.ethereum
    const acctResp = await api.getAccountByWalletAddress(wallet)
    console.log(acctResp)
    console.log(acctResp.accountId)
    console.log(ethereum)
    if (acctResp.accountId) {
      console.log(acctResp.keySeed)
      const signature = await ethereum.request({
        method: 'personal_sign',
        params: [acctResp.keySeed, wallet],
      })
      console.log(signature)
      const apiKey = await api.getAccountApiKey(acctResp.accountId, signature)
    }

    //  const appKey = await ethereum.request({
    //    method: 'eth_chainId',
    //   })
    console.log('-----END TESTING----')
    return acctResp

    // return
    // const message = 'Hello from Ethereum Stack Exchange!'
    // const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
    // const account = accounts[0]
    // const signature = await ethereum.request({
    //   method: 'personal_sign',
    //   params: [message, account],
    // })
    // const signature = await ethereum.request({
    //   method: 'eth_sign',
    // })
    console.log(signature)
    return signature
  },
  async ipfsCIDfromnftId(nftId) {
    if (!nftId) return null
    console.log(sdk)
    const ipfs = await sdk.NFTAPI.prototype.ipfsNftIDToCid(nftId)
    return ipfs
  },
}
