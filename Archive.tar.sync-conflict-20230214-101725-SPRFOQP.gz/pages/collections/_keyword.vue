<script>
import CollectionCard from '@/components/collection-card.vue'
import collectionMixin from '@/mixins/collection-mixin.vue'

export default {
  name: 'collection-list',
  components: { CollectionCard },
  mixins: [collectionMixin],
  methods: {
    async addNftToCollection({ collection = {}, nft = {} }) {
      console.log('addNftToCollection')
      await this.setCollectionSelected(collection)
      this.$store.dispatch('setModalData', nft)
      this.$store.dispatch('toggleModal', 'nft-add')
    },
    async onOpenCollection(collection) {
      console.log('onOpenCollection')
      console.log(collection)
      // this.$router.push({ path: `/collections/collection/${collection.id}` })
      this.$store.dispatch('setContentLoading', true)
      await this.setCollectionSelected(collection)
      this.$store.dispatch('setView', 'collection')
      console.log('onOpenCollection ---- end')
    },
  },
}
</script>
<template>
  <div class="full-width flex-column content-center">
    <collection-card
      v-for="collection in collectionsDisplayed"
      :key="collection.id"
      :collection="collection"
      @addNftToCollection="addNftToCollection"
      @openCollection="onOpenCollection"
    ></collection-card>
  </div>
</template>

<style lang="scss" scoped></style>
