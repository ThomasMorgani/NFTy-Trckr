<script>
import CollectionsWelcome from '@/components/collections-welcome.vue'

export default {
  components: { CollectionsWelcome },
}
</script>

<template>
  <collections-welcome></collections-welcome>
</template>

<style lang="scss" scoped></style>
