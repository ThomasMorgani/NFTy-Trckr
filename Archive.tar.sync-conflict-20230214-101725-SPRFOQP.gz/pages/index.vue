<script>
import CommentCard from '@/components/comment-card.vue'
import WalletButton from '@/components/wallet-button.vue'

export default {
  name: 'NiftyRedditTracker',
  components: {
    CommentCard,
    WalletButton,
  },
  computed: {},
  methods: {},
  async mounted() {
    console.log('welcome')
  },
}
</script>

<template>
  <section class="section">
    <article class="nes-container full-width is-dark">
      <p>Welcome to NFTy-Trckr!</p>
      <p>Keep track of and distribute NFTs easily</p>
      <p class="nes-text is-warning">
        ! App is under active development. <br />
        Expect the following features soon:
      </p>
      <ul>
        <li>Wallet Auth</li>
        <li>Send directly from app</li>
        <li>Reply on social from app</li>
        <li>Import/export data</li>
        <li>Multi chain support</li>
      </ul>
    </article>
    <article class="nes-container full-width has-title is-dark">
      <p class="tile">Status</p>
      <p>Show configuration status, btns to handle</p>
    </article>
  </section>
</template>

<style></style>
