<script>
import { mapGetters, mapState } from 'vuex'
const LOOPRING_PINATA_URL = 'https://loopring.mypinata.cloud/ipfs/'
import api from '@/services/api.js'
import db from '@/services/db.js'
import utils from '@/services/utils.js'
export default {
  name: 'nft-mixin',
  computed: {
    ...mapState({
      collections: (state) => state.collections,
    }),
  },
  methods: {
    async addNftToCollection(collectionId, nftId) {
      const isSelectedCollection =
        collectionId === this.collectionSelectedData?.id

      const collection = isSelectedCollection
        ? { ...this.collectionSelectedData }
        : await db.get('collections', collectionId)

      const existingItems = isSelectedCollection
        ? [...this.collectionSelectedItems]
        : this.getCollectionNFTs(nftId)

      const collectionItems = [...existingItems, nftId]

      collection.itemCount = collectionItems.length

      try {
        await db.put('collection-items', {
          id: collectionId,
          items: collectionItems,
        })
        await db.put('collections', collection)
        const collections = [
          ...this.collections.filter((c) => c.id !== collection.id),
          collection,
        ]
        this.$store.dispatch('setCollections', collections)

        if (isSelectedCollection) {
          this.$store.dispatch('setCollectionSelectedData', collection)
          this.$store.dispatch('setCollectionSelectedItems', collectionItems)
        }
      } catch (e) {
        console.log('error updating collection from addNftToCollection.... ')
      }
    },
    animation(nft) {
      const ipfs =
        nft?.metadata?.extra?.animationUrl || nft?.metadata?.animation_url || ''
      return this.imageSrc(ipfs)
    },
    description(nft) {
      return nft.metadata?.base?.description || nft?.metadata?.description
    },
    async getCollectionNFTs(nftId) {
      const res = await db.get('collection-items', nftId)
      return res?.items || []
    },
    async getNftHolders(nftData) {
      const holders = await api.getNftHolders(nftData)
      console.log(holders?.data || holders)
      return holders
    },
    image(nft) {
      //TODO: make nft mixin
      return nft?.metadata?.imageSize
        ? Object.values(nft.metadata.imageSize)[0]
        : nft?.metadata?.image
        ? this.imageSrc(nft.metadata.image)
        : ''
    },

    imageSrc(ipfs) {
      console.log(ipfs)
      return ipfs ? ipfs.replace('ipfs://', LOOPRING_PINATA_URL) : ''
      // : '/question-mark-block.png'
    },
    name(nft) {
      return nft?.metadata?.base?.name || nft?.metadata?.name || ''
    },
    normalizeNft(nft = {}) {
      //hasOwnProperty('color')
      const nftKeys = [
        'createdAt',
        'creatorFeeBips',
        'minter',
        'nftBaseUri',
        'nftData',
        'nftFactory',
        'nftId',
        'nftType',
        'originalMinter',
        'originalRoyaltyPercentage',
        'nftOwner',
        'royaltyAddress',
        'royaltyPercentage',
        'status',
        'tokenAddress',
      ]
      const metadataKeys = ['animation', 'description', 'image', 'name']
      const nftNormalized = { createdAtHuman: null, metadata: {} }

      nftKeys.forEach(
        (k) => (nftNormalized[k] = nft.hasOwnProperty(k) ? nft[k] : null)
      )
      metadataKeys.forEach((k) => (nftNormalized.metadata[k] = this[k](nft)))

      if (nftNormalized.createdAt)
        nftNormalized.createdAtHuman = utils.epochToHuman(
          nftNormalized.createdAt
        )
      return nftNormalized
    },
    removeNftFromCollection(collectionId, nftId) {
      console.log(collectionId)
      console.log(nftId)
      return new Promise(async (res, rej) => {
        const isSelectedCollection =
          collectionId === this.collectionSelectedData?.id

        const collection = isSelectedCollection
          ? { ...this.collectionSelectedData }
          : await db.get('collections', collectionId)

        const existingItems = isSelectedCollection
          ? [...this.collectionSelectedItems]
          : this.getCollectionNFTs(nftId)

        const collectionItems = [...existingItems.filter((i) => i.id !== nftId)]
        collection.itemCount = collectionItems.length

        try {
          await db.put('collection-items', {
            id: collectionId,
            items: collectionItems,
          })
          await db.put('collections', collection)
          const collections = [
            ...this.collections.filter((c) => c.id !== collection.id),
            collection,
          ]
          this.$store.dispatch('setCollections', collections)

          if (isSelectedCollection) {
            this.$store.dispatch('setCollectionSelectedData', collection)
            this.$store.dispatch('setCollectionSelectedItems', collectionItems)
          }
          res()
        } catch (e) {
          console.log('error updating collection from addNftToCollection.... ')
          console.log(e)
          rej(e.message)
        }
      })
    },
  },
}
</script>
