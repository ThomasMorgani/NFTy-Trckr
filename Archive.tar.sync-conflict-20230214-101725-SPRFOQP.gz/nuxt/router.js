import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0e76b959 = () => interopDefault(import('../pages/collections.vue' /* webpackChunkName: "pages/collections" */))
const _92c1cdc8 = () => interopDefault(import('../pages/collections/index.vue' /* webpackChunkName: "pages/collections/index" */))
const _b0f8d322 = () => interopDefault(import('../pages/collections/collection/_id.vue' /* webpackChunkName: "pages/collections/collection/_id" */))
const _59284650 = () => interopDefault(import('../pages/collections/_keyword.vue' /* webpackChunkName: "pages/collections/_keyword" */))
const _9816d108 = () => interopDefault(import('../pages/tracker.vue' /* webpackChunkName: "pages/tracker" */))
const _9141f1d4 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/collections",
    component: _0e76b959,
    children: [{
      path: "",
      component: _92c1cdc8,
      name: "collections"
    }, {
      path: "collection/:id?",
      component: _b0f8d322,
      name: "collections-collection-id"
    }, {
      path: ":keyword",
      component: _59284650,
      name: "collections-keyword"
    }]
  }, {
    path: "/tracker",
    component: _9816d108,
    name: "tracker"
  }, {
    path: "/",
    component: _9141f1d4,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
