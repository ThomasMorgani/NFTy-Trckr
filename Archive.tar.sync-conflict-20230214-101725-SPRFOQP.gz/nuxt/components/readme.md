# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<ClipboardContainer>` | `<clipboard-container>` (components/clipboard-container.vue)
- `<CollectionCard>` | `<collection-card>` (components/collection-card.vue)
- `<CollectionEdit>` | `<collection-edit>` (components/collection-edit.vue)
- `<CollectionItemList>` | `<collection-item-list>` (components/collection-item-list.vue)
- `<CollectionsWelcome>` | `<collections-welcome>` (components/collections-welcome.vue)
- `<CommentCard>` | `<comment-card>` (components/comment-card.vue)
- `<DetailCard>` | `<detail-card>` (components/detail-card.vue)
- `<ErrorMessage>` | `<error-message>` (components/error-message.vue)
- `<FooterMain>` | `<footer-main>` (components/footer-main.vue)
- `<HeaderCollections>` | `<header-collections>` (components/header-collections.vue)
- `<HeaderMain>` | `<header-main>` (components/header-main.vue)
- `<ImageMissing>` | `<image-missing>` (components/image-missing.vue)
- `<ListStats>` | `<list-stats>` (components/list-stats.vue)
- `<Loader>` | `<loader>` (components/loader.vue)
- `<Modal>` | `<modal>` (components/modal.vue)
- `<Navigation>` | `<navigation>` (components/navigation.vue)
- `<NftAdd>` | `<nft-add>` (components/nft-add.vue)
- `<NftCardCollection>` | `<nft-card-collection>` (components/nft-card-collection.vue)
- `<NftCardNifty>` | `<nft-card-nifty>` (components/nft-card-nifty.vue)
- `<NftCardTracker>` | `<nft-card-tracker>` (components/nft-card-tracker.vue)
- `<NftDetailed>` | `<nft-detailed>` (components/nft-detailed.vue)
- `<NftPreview>` | `<nft-preview>` (components/nft-preview.vue)
- `<PageHeader>` | `<page-header>` (components/page-header.vue)
- `<Snackbar>` | `<snackbar>` (components/snackbar.vue)
- `<Spinner>` | `<spinner>` (components/spinner.vue)
- `<UnusedWalletButtonMultiple>` | `<unused-wallet-button-multiple>` (components/unused_wallet-button-multiple.vue)
- `<WalletButton>` | `<wallet-button>` (components/wallet-button.vue)
