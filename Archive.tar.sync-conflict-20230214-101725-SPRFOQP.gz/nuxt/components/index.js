export { default as ClipboardContainer } from '../../components/clipboard-container.vue'
export { default as CollectionCard } from '../../components/collection-card.vue'
export { default as CollectionEdit } from '../../components/collection-edit.vue'
export { default as CollectionItemList } from '../../components/collection-item-list.vue'
export { default as CollectionsWelcome } from '../../components/collections-welcome.vue'
export { default as CommentCard } from '../../components/comment-card.vue'
export { default as DetailCard } from '../../components/detail-card.vue'
export { default as ErrorMessage } from '../../components/error-message.vue'
export { default as FooterMain } from '../../components/footer-main.vue'
export { default as HeaderCollections } from '../../components/header-collections.vue'
export { default as HeaderMain } from '../../components/header-main.vue'
export { default as ImageMissing } from '../../components/image-missing.vue'
export { default as ListStats } from '../../components/list-stats.vue'
export { default as Loader } from '../../components/loader.vue'
export { default as Modal } from '../../components/modal.vue'
export { default as Navigation } from '../../components/navigation.vue'
export { default as NftAdd } from '../../components/nft-add.vue'
export { default as NftCardCollection } from '../../components/nft-card-collection.vue'
export { default as NftCardNifty } from '../../components/nft-card-nifty.vue'
export { default as NftCardTracker } from '../../components/nft-card-tracker.vue'
export { default as NftDetailed } from '../../components/nft-detailed.vue'
export { default as NftPreview } from '../../components/nft-preview.vue'
export { default as PageHeader } from '../../components/page-header.vue'
export { default as Snackbar } from '../../components/snackbar.vue'
export { default as Spinner } from '../../components/spinner.vue'
export { default as UnusedWalletButtonMultiple } from '../../components/unused_wallet-button-multiple.vue'
export { default as WalletButton } from '../../components/wallet-button.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
