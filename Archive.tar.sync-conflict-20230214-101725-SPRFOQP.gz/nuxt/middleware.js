const middleware = {}

middleware['set-view'] = require('../middleware/set-view.js')
middleware['set-view'] = middleware['set-view'].default || middleware['set-view']

export default middleware
