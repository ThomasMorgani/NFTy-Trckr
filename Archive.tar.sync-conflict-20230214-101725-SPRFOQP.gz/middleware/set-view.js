export default ({ route, store }) => {
  //hacky way to track view within components
  const pathArr = route.path.split('/')
  const [view, subview] = pathArr.slice(1)

  store.dispatch('setView', view)
  store.dispatch('setSubView', subview)
}
