<script>
import 'nes.css/css/nes.min.css'
import FooterMain from '@/components/footer-main.vue'
import HeaderMain from '@/components/header-main.vue'
import Snackbar from '@/components/snackbar.vue'
export default {
  name: 'default-layout',
  components: {
    FooterMain,
    HeaderMain,
    Snackbar,
  },
  computed: {
    isLoading() {
      return this.$store.state.isLoading
    },
    scrollPos() {},
  },
  methods: {
    onScroll(e) {
      console.log(e)
    },
    scrollTop() {
      //todo: create content element where this
      //button is attached to. dont prefer using watchers
      this.$store.dispatch('setScrollElementPos', 0)
      return
      if (this.$store.state.scrollElement) {
        this.$store.state.scrollElement.scrollTo({ top: 0, behavior: 'smooth' })
      }
    },
  },
  mounted() {
    console.log('hello from default layout')
    this.$store.dispatch('appInitialize')
    // const routeParams = this?.$route?.params
    // if (routeParams?.view) {
    //   this.$store.dispatch('setView', routeParams.view)
    // }
  },
}
</script>

<template>
  <main v-if="!isLoading">
    <header-main></header-main>
    <!-- page specific sticky sub headers -->
    <page-header></page-header>
    <Nuxt class="nuxt" />
    <button
      type="button"
      class="nes-btn is-error scroll-btn"
      :class="{ active: scrollPos > 500 }"
      @click="scrollTop"
    >
      <span class="scroll-btn-icon">&lt;</span>
    </button>
    <snackbar></snackbar>
    <footer-main></footer-main>
  </main>
</template>
<style>
/* GLOBAL STYLES */

:root {
  --base-padding: 2rem;
  --background-color-dark: #212529;
  --background-color: #5b5b5b;
  --primary-color: #fff;
  --header-height: 6rem;
}

body {
  color: var(--primary-color);
  line-height: 2;
  box-sizing: border-box;
}

main {
  /* padding: var(--base-padding); */

  display: flex;
  flex-direction: column;
  position: relative;
  padding-bottom: 4rem; /* above footer */
  height: 100vh;
  background-color: var(--background-color);
  /* background-color: #212529; */
}

h1,
h2,
h3,
h4,
h5,
h6 {
  margin: 0;
}

p {
  margin: 0;
}

input.is-disabled,
textarea.is-disabled {
  opacity: 0.7;
  border-color: rgba(118, 118, 118, 0.3);
}

/* NES OVERRIDES */

.nes-container.with-title > .title {
  /* background-color: var(--background-color) !important; */
  margin: -2.4rem 0 1rem;
}

.nes-container.is-rounded {
  /* chrome doesnt like this set to repeat */
  border-image-repeat: stretch !important;
}

.nes-btn {
  /* chrome doesnt like this set to repeat */
  border-image-repeat: stretch !important;
}

.nes-radio {
  margin-right: 0px;
}

.nes-select select {
  /* chrome doesnt like this set to repeat */
  border-image-repeat: stretch !important;
}

/* UTILITY */

.align-center {
  align-content: center;
}

.disable-scroll {
  overflow: hidden !important;
}

.flex-column {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.flex-row {
  display: flex;
  align-items: center;
}

.content-between {
  justify-content: space-between;
}

.flex-end {
  align-items: flex-end;
}

.flex-grow {
  flex-grow: 1;
  flex-shrink: 0;
}

.flex-wrap {
  flex-wrap: wrap;
}

.full-height {
  height: 100%;
}

.full-width {
  width: 100%;
}

.m0 {
  margin: 0px;
}

.ma {
  margin: var(--base-padding);
}

.mb {
  margin-bottom: var(--base-padding);
}

.mb-auto {
  margin-bottom: auto;
}

.ml {
  margin-left: var(--base-padding);
}
.ml-auto {
  margin-left: auto;
}

.mr {
  margin-right: var(--base-padding);
}

.mr-auto {
  margin-right: auto;
}

.mt {
  margin-top: var(--base-padding);
}
.mt-auto {
  margin-top: auto;
}

.mx {
  margin-inline: var(--base-padding);
}

.mx-auto {
  margin-inline: auto;
}

.my {
  margin-block: var(--base-padding);
}

.p0 {
  padding: 0px;
}

.pa {
  padding: var(--base-padding);
}

.pb {
  padding-bottom: var(--base-padding);
}
.pl {
  padding-left: var(--base-padding);
}

.pt {
  padding-top: var(--base-padding);
}

.px {
  padding-inline: var(--base-padding);
}
.py {
  padding-block: var(--base-padding);
}

.pointer {
  cursor: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAzElEQVRYR+2X0Q6AIAhF5f8/2jYXZkwEjNSVvVUjDpcrGgT7FUkI2D9xRfQETwNIiWO85wfINfQUEyxBG2ArsLwC0jioGt5zFcwF4OYDPi/mBYKm4t0U8ATgRm3ThFoAqkhNgWkA0jJLvaOVSs7j3qMnSgXWBMiWPXe94QqMBMBc1VZIvaTu5u5pQewq0EqNZvIEMCmxAawK0DNkay9QmfFNAJUXfgGgUkLaE7j/h8fnASkxHTz0DGIBMCnBeeM7AArpUd3mz2x3C7wADglA8BcWMZhZAAAAAElFTkSuQmCC)
      14 0,
    pointer !important;
}

.section {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: var(--base-padding);
}

.action-btn {
  line-height: 1;
  font-weight: bold;
  font-size: 1.5rem;
  height: 48px;
  width: 48px;
}

.action-btn img {
  height: 24px;
  width: 24px;
}

/* Scroll back to top */
.scroll-btn {
  position: fixed;
  bottom: -60px;
  right: var(--base-padding);
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.6);
  transition: all 0.3s ease;
  z-index: 19;
}
.scroll-btn.active {
  bottom: 25px;
}
.scroll-btn > span {
  display: block;
  transform: rotateZ(90deg);
}
.scroll-btn-icon {
  margin-right: 0.25rem;
}

/* animations */
.fade-in {
  animation: fadeIn 2s;
}

.rotate {
  animation: rotation 1s infinite linear;
}

@keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

@keyframes rotation {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(-360deg);
  }
}
</style>
