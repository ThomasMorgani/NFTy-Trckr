<script>
import CollectionList from '~/components/collection-item-list.vue'
import collectionMixin from '@/mixins/collection-mixin.vue'
import db from '@/services/db'
export default {
  name: 'collection-page',
  mixins: [collectionMixin],
  components: { CollectionList },
  async mounted() {
    console.log('COLL PAGE')
    console.log(this?.$route?.params?.id)
    console.log(this?.$route)
    const { collectionSelectedData, collectionSelectedItems } =
      this.$store.state
    console.log(this?.$route?.params?.id)
    console.log(collectionSelectedData?.id)
    this.$store.dispatch('setContentLoading', true)
    if (this?.$route?.params?.id) {
      db.setLocalStorage('last-collection', this.$route.params.id)
      if (this.$route.params.id !== collectionSelectedData?.id) {
        const hi = await this.setCollectionSelected(this.$route.params.id)
        console.log(hi)
      }
      this.$store.dispatch('setContentLoading', false)
      return
    }

    console.log('no params id')

    // if (collectionSelectedData?.id) {
    //   this.$router.push({
    //     path: `${this.$route.fullPath}/${lastViewedCollection}`,
    //   })
    // }
    //TODO: get last view localStorage
    const lastViewedCollection = collectionSelectedData?.id
      ? collectionSelectedData.id
      : db.getLocalStorage('last-collection') || 'nifty'
    console.log(lastViewedCollection)
    console.log(this.$route.fullPath)
    await this.setCollectionSelected(lastViewedCollection)
    console.log('push route', `${this.$route.fullPath}/${lastViewedCollection}`)
    // this.$router.push({
    //   path: `${this.$route.fullPath}/${lastViewedCollection}`,
    // })
    console.log('loading false')
    this.$store.dispatch('setContentLoading', false)
    console.log('collection created done')
  },
}
</script>

<template>
  <collection-list v-if="!$store.state.contentLoading"></collection-list>
</template>

<style lang="scss" scoped></style>
