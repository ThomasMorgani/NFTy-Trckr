<script>
import CollectionList from '~/components/collection-item-list.vue'
import collectionMixin from '@/mixins/collection-mixin.vue'
import db from '@/services/db'
export default {
  name: 'collection-page',
  mixins: [collectionMixin],
  components: { CollectionList },
  async created() {
    console.log('COLL PAGE')
    const { collectionSelectedData, collectionSelectedItems } =
      this.$store.state
    this.$store.dispatch('setContentLoading', true)
    if (this?.$route?.params?.id) {
      console.log(this.$route.params.id)
      console.log(collectionSelectedData?.id)
      db.setLocalStorage('last-collection', this.$route.params.id)
      if (this.$route.params.id !== collectionSelectedData?.id) {
        console.log('not equal')
        const hi = await this.setCollectionSelected(this.$route.params.id)
        console.log(hi)
      }
      this.$store.dispatch('setContentLoading', false)
      return
    }

    console.log('no params id')

    if (collectionSelectedData?.id) {
      //   this.$router.push({
      //     path: `${this.$route.fullPath}/${lastViewedCollection}`,
      //   })
      console.log('selectedData exists')
      console.log('loading false')
      this.$store.dispatch('setContentLoading', false)
      return
    }
    //TODO: get last view localStorage
    // return
    const lastViewedCollection = collectionSelectedData?.id
      ? collectionSelectedData.id
      : db.getLocalStorage('last-collection') || 'nifty'
    // console.log(collectionSelectedData)
    // console.log(lastViewedCollection)
    // console.log(this.$route.fullPath)
    await this.setCollectionSelected(lastViewedCollection)
    console.log('push route', `${this.$route.fullPath}/${lastViewedCollection}`)
    // this.$router.push({
    //   path: `${this.$route.fullPath}/${lastViewedCollection}`,
    // })
    console.log('loading false')
    this.$store.dispatch('setContentLoading', false)
    console.log('collection created done')
  },
}
</script>

<template>
  <!-- <p>test</p> -->
  <collection-list v-if="!$store.state.contentLoading"></collection-list>
</template>

<style lang="scss" scoped></style>
