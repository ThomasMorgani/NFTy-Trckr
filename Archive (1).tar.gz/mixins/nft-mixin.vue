<script>
import { mapGetters, mapState } from 'vuex'
const LOOPRING_PINATA_URL = 'https://loopring.mypinata.cloud/ipfs/'
import api from '@/services/api.js'
import db from '@/services/db.js'
import utils from '@/services/utils.js'
export default {
  name: 'nft-mixin',
  computed: {
    ...mapState({
      collections: (state) => state.collections,
      connectedAccount: (state) => state.connectedAccount,
      connectedWallet: (state) => state.connectedWallet,
    }),
  },
  methods: {
    async addNftToCollection(collectionId, nftId) {
      const isSelectedCollection =
        collectionId === this.collectionSelectedData?.id

      const collection = isSelectedCollection
        ? { ...this.collectionSelectedData }
        : await db.get('collections', collectionId)

      const existingItems = isSelectedCollection
        ? [...this.collectionSelectedItems]
        : this.getCollectionNFTs(nftId)

      const collectionItems = [...existingItems, nftId]

      collection.itemCount = collectionItems.length

      try {
        await db.put('collection-items', {
          id: collectionId,
          items: collectionItems,
        })
        await db.put('collections', collection)
        const collections = [
          ...this.collections.filter((c) => c.id !== collection.id),
          collection,
        ]
        this.$store.dispatch('setCollections', collections)

        if (isSelectedCollection) {
          this.$store.dispatch('setCollectionSelectedData', collection)
          this.$store.dispatch('setCollectionSelectedItems', collectionItems)
        }
      } catch (e) {
        console.log('error updating collection from addNftToCollection.... ')
      }
    },
    animation(nft) {
      const ipfs =
        nft?.metadata?.extra?.animationUrl || nft?.metadata?.animation_url || ''
      return this.imageSrc(ipfs)
    },
    description(nft) {
      return nft.metadata?.base?.description || nft?.metadata?.description
    },
    async getAccountNftBalances(
      accountId,
      network = 'loopring',
      metadata = true
    ) {
      if (!accountId) {
        console.error('no account ID received')
        return
      }
      let balances = []
      try {
        if (network === 'loopring') {
          balances = await api.getUserNftBalancesLoopring(accountId, metadata)
        }
        const balancesNorm = balances.map((nft) => this.normalizeNft(nft))
        return balancesNorm
      } catch (e) {
        console.log('error getAccountNftBalances')
        throw Error(e.message || 'Error getting Account NFT Balances')
      }
    },
    async getCollectionNFTs(nftId) {
      const res = await db.get('collection-items', nftId)
      return res?.items || []
    },
    async getNftHolders(nftData, withAccountInfo = false) {
      const holders = await api.getNftHolders(nftData)
      console.log(holders)
      if (withAccountInfo && holders.nftHolders) {
        for (let key in holders.nftHolders) {
          console.log(key)
          console.log(holders.nftHolders[key])

          const accountInfo = await api.getAccountInfo(
            holders.nftHolders[key].accountId
          )
          //For now just pulling out wallet
          holders.nftHolders[key].owner = accountInfo.owner
        }
      }
      return holders
    },
    image(nft) {
      //TODO: make nft mixin
      return nft?.metadata?.imageSize
        ? Object.values(nft.metadata.imageSize)[0]
        : nft?.metadata?.image
        ? this.imageSrc(nft.metadata.image)
        : ''
    },

    imageSrc(ipfs) {
      // console.log(ipfs)
      return ipfs ? ipfs.replace('ipfs://', LOOPRING_PINATA_URL) : ''
      // : '/question-mark-block.png'
    },
    name(nft) {
      return nft?.metadata?.base?.name || nft?.metadata?.name || ''
    },
    normalizeNft(nft = {}) {
      //hasOwnProperty('color')
      const nftKeys = [
        'createdAt',
        'creatorFeeBips',
        'minter',
        'nftBaseUri',
        'nftData',
        'nftFactory',
        'nftId',
        'nftType',
        'originalMinter',
        'originalRoyaltyPercentage',
        'nftOwner',
        'royaltyAddress',
        'royaltyPercentage',
        'status',
        'tokenAddress',
      ]
      const metadataKeys = ['animation', 'description', 'image', 'name']
      const nftNormalized = { createdAtHuman: null, metadata: {} }

      nftKeys.forEach(
        (k) => (nftNormalized[k] = nft.hasOwnProperty(k) ? nft[k] : null)
      )

      //TODO: handle possible props: base, extra, ??
      const metadata = nft?.metadata || {}
      const metadataBase = nft?.metadata?.base || {}
      const metadataExtra = nft?.metadata?.extra || {}
      nftNormalized.metadata = {
        ...metadata,
        ...metadataBase,
        ...metadataExtra,
      }
      // console.log(nftNormalized)

      metadataKeys.forEach((k) => (nftNormalized.metadata[k] = this[k](nft)))
      if (nft?.metadata?.imageSize)
        nftNormalized.metadata.imageSize = nft.metadata.imageSize

      // if (nft?.metadata?.extra)
      //   nftNormalized.metadata.extra = nft.metadata.extra

      if (nftNormalized.createdAt)
        nftNormalized.createdAtHuman = utils.epochToHuman(
          nftNormalized.createdAt
        )
      return nftNormalized
    },
    removeNftFromCollection(collectionId, nftId) {
      return new Promise(async (res, rej) => {
        const isSelectedCollection =
          collectionId === this.collectionSelectedData?.id

        const collection = isSelectedCollection
          ? { ...this.collectionSelectedData }
          : await db.get('collections', collectionId)

        const existingItems = isSelectedCollection
          ? [...this.collectionSelectedItems]
          : this.getCollectionNFTs(nftId)

        const collectionItems = [...existingItems.filter((i) => i.id !== nftId)]
        collection.itemCount = collectionItems.length

        try {
          await db.put('collection-items', {
            id: collectionId,
            items: collectionItems,
          })
          await db.put('collections', collection)
          const collections = [
            ...this.collections.filter((c) => c.id !== collection.id),
            collection,
          ]
          this.$store.dispatch('setCollections', collections)

          if (isSelectedCollection) {
            this.$store.dispatch('setCollectionSelectedData', collection)
            this.$store.dispatch('setCollectionSelectedItems', collectionItems)
          }
          res()
        } catch (e) {
          console.log('error updating collection from addNftToCollection.... ')
          console.log(e)
          rej(e.message)
        }
      })
    },
    async syncCollectionWalletItems(collection) {
      try {
        const account =
          this.connectedWallet === collection.address
            ? this.connectedAccount
            : await api.getAccountInfo(null, collection.address)
        //get balances of network (only loopring now)
        const balances = await this.getAccountNftBalances(account.accountId)
        const balancesNormalized = []
        // console.log(balances)
        if (balances.length < 1) return balances
        for (let nft of balances) {
          const nftWithMeta = await api.getNftInfoByNftData(nft.nftData)
          const nftNormalized = this.normalizeNft(nftWithMeta)
          balancesNormalized.push(nftNormalized)
          const existingNFT = await db.get('nfts', nftNormalized.nftId)
          if (!existingNFT) {
            db.add('nfts', nftNormalized, 'nftId')
          }
          await this.addNftToCollection(collection.id, nftNormalized.nftId)
        }
        return balancesNormalized
      } catch (e) {
        console.log('error syncCollectionWalletItems')
        throw Error(e.message || 'Error syncing colleciton Wallet items')
      }
    },
  },
}
</script>
