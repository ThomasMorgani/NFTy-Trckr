<script>
import { mapGetters, mapState } from 'vuex'
import api from '@/services/api.js'
import db from '@/services/db.js'

import utils from '@/services/utils.js'
export default {
  name: 'collection-mixin',
  data: () => ({
    defaultCollection: {
      created_at: null,
      id: null,
      isWallet: false,
      itemCount: 0,
      name: '',
      note: '',
      updated_at: null,
      // wallet: {
      //   accountId: null,
      //   address: '',
      // },
    },
  }),
  computed: {
    ...mapGetters([
      // 'allCollections',
      // 'collectionItemsDisplayed',
    ]),
    ...mapState({
      collectionItemsData: (state) => state.collectionItemsData,
      collections: (state) => state.collections,
      collectionsHeader: (state) => state.collectionsHeader,
      collectionSelectedData: (state) => state.collectionSelectedData,
      collectionSelectedItems: (state) => state.collectionSelectedItems,
      connectedWallet: (state) => state.connectedWallet,
      contentLoading: (state) => state.contentLoading,
      view: (state) => state.collectionsHeader.view,
      walletError: (state) => state.walletError,
    }),
    // async collectionItems() {
    //   if (!this.collectionSelectedData?.id) return []
    //   const items = await db.get(
    //     'collection-items',
    //     this.collectionSelectedData.id
    //   )
    //   return items
    // },
    collectionItemsDisplayed() {
      //TODO: create method to filter items,
      //take array, searchables, search
      //TODO: create method sort
      //take array, key, direction
      const { filters, sortSelect } = this.collectionsHeader
      let items = this.collectionSelectedItems || []
      if (filters.search) {
        items = [
          ...items.filter((i) => {
            const {
              accountId,
              nftId,
              tokenAddress,
              uri,
              nftData,
              nftType,
              tokenId,
            } = i || ''
            const { name, description } = i?.metadata || ''

            const searchables = {
              accountId,
              nftId,
              tokenAddress,
              uri,
              nftData,
              nftType,
              tokenId,
              name,
              description,
            }
            const searchableString = Object.values(searchables).join('')
            return searchableString
              .toLowerCase()
              .includes(filters.search.toLowerCase())
          }),
        ]
      }
      return items
    },
    collectionsDisplayed() {
      return [...this.collections].sort((a, b) => b.updated_at - a.updated_at)
      // return getters.allCollections
    },
  },
  methods: {
    async collectionUpsert(collection = {}) {
      const newCollection = { ...this.defaultCollection, ...collection }
      if (!collection.id) {
        newCollection.id = collection?.isWallet
          ? collection.address
          : utils.generateId()
        newCollection.created_at = new Date().getTime()
      }
      newCollection.updated_at = new Date().getTime()
      newCollection.isWallet = !!collection.address
      console.log(newCollection)

      try {
        await db.put('collections', newCollection)
        console.log(newCollection)
        console.log(this.collections)
        const collections = [
          ...this.collections.filter((c) => c.id !== newCollection.id),
          { ...newCollection },
        ]
        console.log(collections)
        this.$store.dispatch('setCollections', collections)
      } catch (e) {
        console.log(e)
      }
      // this.$store.dispatch('setCollections', [
      //   ...this.collections,
      //   this.collection,
      // ])
      // db.write('collections')
      // not saving items here, just meta
      // db.write([this.collection.id], this.collection)
    },
    async collectionDelete(collection) {
      try {
        await db.delete('collections', collection)
        const collections = this.collections.filter(
          (c) => c.id !== this.collection.id
        )
        this.$store.dispatch('setCollections', collections)
      } catch (e) {
        console.log(e)
      }
      // this.$store.dispatch('setCollections', [
      //   ...this.collections,
      //   this.collection,
      // ])
      // db.write('collections')
      // not saving items here, just meta
      // db.write([this.collection.id], this.collection)
    },
    collectionEdit(collection) {
      console.log(collection)
      this.$store.dispatch('setModalData', collection)
      this.$store.dispatch('toggleModal', 'collection-edit')
    },
    collectionImage(collection) {
      //isNft joystick
      //isCustom pokedex
      //isWallet money bag
      return
    },
    setCollectionSelected(selected) {
      return new Promise(async (res, rej) => {
        console.log(selected)
        const collection = selected?.id
          ? selected
          : await db.get('collections', selected)
        const items = await db.get('collection-items', collection.id)
        console.log(collection)
        console.log(items)
        this.$store.dispatch('setCollectionSelectedData', collection)
        this.$store.dispatch('setCollectionSelectedItems', items?.items || [])
        this.$store.dispatch('setCollectionItemsData', [])

        res('ww')
      })
    },
    updateCollectionsHeader(data) {
      this.$store.dispatch('setCollectionsHeader', {
        ...this.collectionsHeader,
        ...data,
      })
    },
  },
}
</script>
