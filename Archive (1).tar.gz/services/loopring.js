import web3 from 'web3'
import api from '@/services/api'

import { LoopringAPIClass, generateKeyPair } from './loopring-sdk'

const LoopringAPI = new LoopringAPIClass()
const w3 = new web3(window.gamestop)
export default {
  async getApiKey(walletAddress, account) {
    // console.log(sdk)
    // sdk.InitApi()
    // console.log(sdk.generateKeyPair)
    console.log(LoopringAPI)
    console.log(w3.eth)
    if (!account?.accountId) {
      console.log('throw error no connected wallet')
      return
    }
    const { accountId, keySeed, owner } = account

    console.log(w3, accountId, keySeed, owner)
    const kp = await generateKeyPair({
      web3: w3,
      address: owner,
      accountId,
      keySeed,
    })

    console.log(kp)

    const { apiKey } = await LoopringAPI.userAPI.getUserApiKey(
      {
        accountId,
      },
      kp.sk
    )
    console.log(apiKey)
    // const apikeytest = await api.getAccountApiKey(account.accountId, x.sk)
    // console.log(apikeytest)
    return apiKey
  },

  async getApiKey_TESTING(account) {
    /*
        working methods:
          eth_chainId
      */
    console.log(account)
    if (!account) return
    const { owner: wallet } = account
    console.log('-----TESTING----')
    const ethereum = window.gamestop || window.ethereum
    // const acctResp = await api.getAccountByWalletAddress(wallet)
    console.log(account)
    console.log(account.accountId)
    console.log(ethereum)
    if (account.accountId) {
      console.log(account.keySeed)
      const signature = await ethereum.request({
        method: 'personal_sign',
        params: [account.keySeed, wallet],
        // params: [account.keySeed, wallet],
      })
      console.log(signature)
      const apiKey = await api.getAccountApiKey(account.accountId, signature)
      console.log(apiKey)
    }

    //  const appKey = await ethereum.request({
    //    method: 'eth_chainId',
    //   })
    console.log('-----END TESTING----')
    return acctResp

    // return
    // const message = 'Hello from Ethereum Stack Exchange!'
    // const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
    // const account = accounts[0]
    // const signature = await ethereum.request({
    //   method: 'personal_sign',
    //   params: [message, account],
    // })
    // const signature = await ethereum.request({
    //   method: 'eth_sign',
    // })
    console.log(signature)
    return signature
  },
  async ipfsCIDfromnftId(nftId) {
    if (!nftId) return null
    console.log(LoopringAPI)
    const ipfs = await LoopringAPI.nftAPI.ipfsNftIDToCid(nftId)
    return ipfs
  },
}
