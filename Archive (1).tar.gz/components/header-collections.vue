<script>
import { mapGetters, mapState } from 'vuex'
import Filters from '@/components/filters.vue'
import ListStats from '@/components/list-stats.vue'

import collectionMixin from '@/mixins/collection-mixin.vue'
import nftMixin from '@/mixins/nft-mixin.vue'

import api from '@/services/api.js'
import db from '@/services/db.js'
import utils from '@/services/utils.js'
import loopring from '@/services/loopring'
export default {
  name: 'header-collections',
  components: {
    Filters,
    ListStats,
  },
  mixins: [collectionMixin, nftMixin],
  data: () => ({
    showFilters: false,
  }),
  computed: {
    ...mapState({
      collections: (state) => state.collections,
      defaultCollections: (state) => state.defaultCollections,
      collectionSelectedData: (state) => state.collectionSelectedData,
      collectionsHeader: (state) => state.collectionsHeader,
      connectedAccount: (state) => state.connectedAccount,
      connectedWallet: (state) => state.connectedWallet,
      contentLoading: (state) => state.contentLoading,
      filters: (state) => state.collectionsHeader.filters,
      subView: (state) => state.subView,
      view: (state) => state.view,
    }),
    collectionSelect: {
      get() {
        return this.collectionsHeader.collectionSelect
      },
      set(v) {
        this.updateCollectionsHeader({ collectionSelect: v })
      },
    },

    radioNav: {
      get() {
        return this.$store.state.subView
      },
      set(v) {
        console.log(v)
        this.$router.push({ path: `/collections/${v}` })
        // this.$store.dispatch('setView', v)
      },
    },
  },
  methods: {
    async apikeyTest() {
      console.log(window.wallet)
      console.log(window.wallet)
      // window.wallet.getApiKey()
      // loopring.getApiKey(this.connectedAccount)
      await loopring.getApiKey(this.connectedWallet, this.connectedAccount)
    },
    onAddButton() {
      // loopring.test()
      this.$store.dispatch('toggleModal', 'collection-edit')
    },
    cacheTime(time_utc) {
      return utils.epochToHuman(time_utc)
    },
    messageText() {
      if (!this.view) return 'Select an option below.'
      if (this.subView === 'all') return 'Collection Library'
      if (this.view === 'collection' && !this.collectionSelectedData?.id)
        return 'No collection selected.'
      if (this.collectionSelectedData?.name)
        return this.collectionSelectedData.name
      return ''
    },
    async refreshCollectionSelectedData() {
      if (this.contentLoading) return
      const selectedCollection = this.collectionSelectedData
      if (!selectedCollection?.id && !selectedCollection?.isWallet) {
        console.log('ONLY REFRESH WALLET COLLECTIONS NOW')
        return
      }
      this.$store.dispatch('setContentLoading', true)
      this.$store.dispatch('setCollectionSelectedItems', [])
      try {
        const res = await this.syncCollectionWalletItems(selectedCollection)
        this.$store.dispatch()
        console.log(res)
      } catch (e) {
        console.log(e.message)
        //Temp error feedback error fix
        const text = e.message.includes('API KEY REQUIRED')
          ? 'Wallet not connected!'
          : e.messages
        this.$store.dispatch('setSnackbar', { show: true, text })
      }
      this.$store.dispatch('setContentLoading', false)
    },
    sortOptionText(option) {
      return option.split('_').join(' ')
    },
    toggleFilters() {
      this.updateCollectionsHeader({ filters: { show: !this.filters.show } })
    },
  },
  created() {
    console.log(this.$route)
    // const view = this?.$route?.params?.view
    // console.log(view)
    // if (!view) return
    // if (view === 'all' || view === 'collection') this.view = view
    // else {
    //   const foundCollection = this.collections.find((c) => c.id === view)
    //   console.log(this.collections)
    //   console.log(this.foundCollection)
    //   console.log(view)
    //   if (foundCollection) {
    //     this.$store.dispatch('setCollectionSelectedData', foundCollection)
    //   }
    // }
  },
}
</script>
<template>
  <section class="page-header pa">
    <article
      class="main-section flex-column nes-container is-rounded with-title full-width"
    >
      <div class="top-section flex-row full-width">
        <!-- TODO: MOVE TO FILTER -->
        <filters v-if="showFilters"></filters>
        <div v-else>
          <h3 class="nes-text is-primary">
            {{ messageText() }}
          </h3>
          <ListStats
            :selectedData="collectionSelectedData"
            :selectedItems="collectionItemsDisplayed"
            :selectedItemsDisplayed="collectionItemsDisplayed"
          />
        </div>
      </div>

      <div class="bottom-section flex-row full-width mt">
        <div class="flex-row">
          <label
            class="nes-text mr"
            :class="`is-${radioNav === 'all' ? 'primary' : ''}`"
          >
            <input
              v-model="radioNav"
              value="all"
              type="radio"
              class="nes-radio"
              name="radio-collection"
            />
            <span>All</span>
          </label>
          <label
            class="nes-text mr"
            :class="`is-${radioNav === 'collection' ? 'primary' : ''}`"
          >
            <input
              v-model="radioNav"
              value="collection"
              type="radio"
              class="nes-radio"
              name="radio-collection"
            />
            <span>Collection</span>
          </label>
        </div>
        <!-- <label
          class="nes-text ml-auto"
          :class="`is-${
            hasFilters ? 'success' : radioNav === 'filters' ? 'primary' : ''
          }`"
        >
          <input
            v-model="showFilters"
            name="enable-filters"
            type="checkbox"
            class="nes-checkbox is-dark"
            :class="`is-${
              hasFilters ? 'success' : radioNav === 'filters' ? 'primary' : ''
            }`"
          />
          <span>Filters</span>
        </label> -->
        <header-buttons
          :showFilters="showFilters"
          @addBtn="onAddButton"
          @filterBtn="showFilters = !showFilters"
          @refreshBtn="refreshCollectionSelectedData"
        />
      </div>

      <!-- <div
        v-if="view === 'collection'"
        class="collection-select flex-row full-width"
      >
        <div class="full-width">
          <div class="nes-select">
          <CollectionSelect/>
          </div>
        </div>
      </div> -->
    </article>
  </section>
</template>
<style lang="css" scoped>
.page-header {
  position: sticky;
  top: var(--header-height);
  padding-bottom: 1rem;
  padding-top: 0px;
  z-index: 5;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  /* background-color: var(--background-color); */
}

.main-section {
  padding: 1rem;
  align-items: flex-start;
  justify-content: space-between;
}

.top-section {
  align-items: flex-start;
  justify-items: flex-start;
  min-height: 120px;
}

.filter-radio {
  margin-left: 1rem;
}

.nes-radio:checked + span::before {
  color: var(--primary-color);
}

.bottom-btns {
  align-items: flex-end;
  margin-left: auto;
}

.top-btns {
  margin-left: auto;
}

.collection-select {
  align-items: center;
  /* display: flex; */
  margin-top: 2rem;
}

.add-collection-btn {
  /* padding: 0.5rem; */
  margin-left: 1.5rem;
}

.bottom-section {
  /* padding-top: 1rem; */
  justify-content: space-between;
  align-items: flex-end;
}

.filters-btn {
  display: flex;
  align-items: flex-start;
  padding-inline: 0.5rem;
}

.filters-btn-icon {
  text-shadow: 1px 1px #212529;
}
</style>
