<script>
import { mapState } from 'vuex'

import NftMixin from '@/mixins/nft-mixin.vue'

import api from '@/services/api.js'
import db from '@/services/db.js'
import loopring from '@/services/loopring.js'
import utils from '@/services/utils.js'
import wallet from '@/services/wallet.js'

export default {
  name: 'wallet-button',
  props: {
    withText: {
      type: Boolean,
      default: () => true,
    },
  },
  mixins: [NftMixin],
  computed: {
    ...mapState({
      apiKeys: (state) => state.apiKeys,
      collectionSelect: (state) => state.collectionsHeader.collectionSelect,
      connectedAccount: (state) => state.connectedAccount,
      connectedWallet: (state) => state.connectedWallet,
    }),
  },
  methods: {
    async connectWallet() {
      const providerAddress = await wallet.getConnectedWalletCurrentAddress()
      console.log(providerAddress)
      if (this.connectedAccount?.owner !== providerAddress) {
        const walletAddress = await wallet.connectWallet()
        if (walletAddress) {
          this.$store.dispatch('setContentLoading', true)
          this.$emit('walletConnected', walletAddress)
          this.$store.dispatch('setConnectedWallet', walletAddress)
          const account = await api.getAccountByWalletAddress(walletAddress)
          console.log(account)
          if (account.error) {
            this.$store.dispatch('setWalletError', account)
            return
          }
          this.$store.dispatch('setConnectedAccount', account)
          // console.log(this.collectionSelect)
          // if (this.collectionSelect === 'connected') {
          //   const balances = await api.getUserNftBalancesLoopring(
          //     account.accountId,
          //     true
          //   )

          //   const balancesFixed = balances.map((nft) => this.normalizeNft(nft))

          //   const collectionItems = db.saveCollectionItems(
          //     walletAddress,
          //     balancesFixed
          //   )
          //   console.log(collectionItems)
          //   this.$store.dispatch('setCollectionItems', collectionItems)
          // }
        }
      } else {
        console.log(this.connectedWallet)
        await utils.copyToClipboard(this.connectedWallet)
        this.$store.dispatch('setSnackbar', {
          show: true,
          text: 'Wallet address copied.',
        })
      }

      if (!this.apiKeys.loopring?.[providerAddress]) {
        const apiKey = await loopring.getApiKey(null, this.connectedAccount)
        if (apiKey) {
          this.$store.dispatch('setApiKeys', {
            ...this.apiKeys,
            loopring: {
              ...this.apiKeys.loopring,
              [this.connectedWallet]: apiKey,
            },
          })
        }
      }
      // const walletAddress = '0xc9441e2bc85bE9fD27E34c7C1424aBa40c83A8fA' //NFTyTrckr wallet

      this.$store.dispatch('setContentLoading', false)
    },
  },
}
</script>
<template>
  <button
    class="wallet-btn nes-btn fade-in"
    :class="`is-${connectedWallet ? 'success' : 'error'}`"
    @click="connectWallet"
  >
    <i class="nes-icon coin is-small"></i>
    <span class="btn-text">
      {{ withText ? 'WALLET' : '' }}
    </span>
  </button>
</template>

<style scoped>
@media screen and (min-width: 500px) and (max-width: 700px) {
  .wallet-btn {
    position: absolute;
    top: 1rem;
    right: 1rem;
  }
}

@media screen and (max-width: 500px) {
  .wallet-btn {
    width: 100%;
    margin-top: 1rem;
  }
}
</style>
