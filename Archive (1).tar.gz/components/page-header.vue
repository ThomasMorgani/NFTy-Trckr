<script>
export default {
  name: 'page-header',
  data: () => ({
    componentsMap: {
      collections: 'collections',
    },
  }),
  components: {
    collections: () => import('@/components/header-collections.vue'),
  },
}
</script>
<template>
  <!-- <component :is="componentsMap[$route.name]"></component> -->
  <collections></collections>
</template>

<style lang="scss" scoped></style>
