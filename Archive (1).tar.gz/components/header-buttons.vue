<script>
import { mapGetters, mapState } from 'vuex'

export default {
  name: 'header-buttons',
  props: {
    showFilters: {
      type: Boolean,
      required: true,
    },
  },
  computed: {
    ...mapState({
      collections: (state) => state.collections,
      defaultCollections: (state) => state.defaultCollections,
      collectionSelectedData: (state) => state.collectionSelectedData,
      collectionsHeader: (state) => state.collectionsHeader,
      connectedAccount: (state) => state.connectedAccount,
      connectedWallet: (state) => state.connectedWallet,
      contentLoading: (state) => state.contentLoading,
      filters: (state) => state.collectionsHeader.filters,
      subView: (state) => state.subView,
      view: (state) => state.view,
    }),
    addDisabled() {
      if (!this.view) return true
      if (this.view === 'collection') {
        return this.subView !== 'all' && this.collectionSelectedData?.isWallet
      }
    },
    hasFilters() {
      return Object.values(this.filters).filter((f) => f).length > 0
    },
    refreshDisabled() {
      return this.subView === 'all' || !this.collectionSelectedData?.isWallet
    },
  },
}
</script>

<template>
  <div class="flex-row flex-end">
    <div class="bottom-btns flex-row">
      <!-- <button @click="apikeyTest">T</button> -->
      <!-- TODO:
            MAKE FILTER BTN COMPONENT
            TOGGLE FILTERS
            COLORS: disabled (off), primary (show), success (filterd applied)
             -->
      <button
        title="Toggle filters."
        class="action-btn nes-btn pointer"
        :class="showFilters ? 'is-primary' : 'is-disabled'"
        @click="$emit('filterBtn')"
      >
        <img src="/funnel-white.png" class="refresh-icon" />
      </button>
      <!-- <button @click="apikeyTest">T</button> -->
      <button
        :disabled="refreshDisabled"
        title="Refresh collection data from blockchain."
        class="action-btn nes-btn ml"
        :class="refreshDisabled ? 'is-disabled' : 'is-success'"
        @click="$emit('refreshBtn')"
      >
        <img
          src="/refresh-icon.png"
          class="refresh-icon"
          :class="{ rotate: contentLoading }"
        />
      </button>
      <button
        :disabled="addDisabled"
        :title="
          subView === 'all'
            ? 'Add new collection.'
            : 'Add a new nft to the selected collection.'
        "
        class="action-btn nes-btn ml"
        :class="addDisabled ? 'is-disabled' : 'is-success'"
        @click="$emit('addBtn')"
      >
        <img src="/plus-white.png" class="refresh-icon" />
      </button>
    </div>
  </div>
</template>

<style></style>
