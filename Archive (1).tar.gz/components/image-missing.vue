<template>
  <!-- <div class="flex-column"> -->
  <img
    src="/question-mark-block.png"
    alt="image place holder - mario question mark block"
    title="Image not found"
  />
  <!-- <span>missing</span> -->
  <!-- <span>image</span> -->
  <!-- </div> -->
</template>

<script>
export default {}
</script>

<style lang="css" scoped>
img {
  height: 3rem;
  width: 3rem;
}
</style>
