<script>
import collectionMixin from '@/mixins/collection-mixin.vue'
export default {
  name: 'collection-card',
  mixins: [collectionMixin],
  props: {
    collection: {
      type: Object,
      required: true,
    },
  },
  // computed: {
  //   collection.isWallet() {
  //     return !this.collection?.isCustom && this.collection.value !== 'nifty'
  //     // || this.collection?.wallet?.address
  //   },
  // },
  computed: {
    isConnectedWallet() {
      return this?.$store?.state?.connectedWallet === this.collection?.address
    },
  },
  methods: {
    onEdit() {
      this.collectionEdit(this.collection)
    },
  },
}
</script>

<template>
  <article class="card nes-container is-rounded is-dark flex-column full-width">
    <nuxt-link :to="`/collections/collection/${collection.id}`">
      <img
        class="info-icon nes-avatar is-medium pointer"
        alt="button to display nft details modal"
        src="/external-link-icon.png"
        title="Show collection items"
      />
    </nuxt-link>

    <!-- @click="$emit('openCollection', collection)" -->
    <section class="content-section flex-row full-width">
      <div class="image-container">
        <i
          v-if="isConnectedWallet"
          title="connected wallet"
          class="nes-icon coin is-large"
        ></i>
        <img
          v-else
          :src="collection.isWallet ? '/money-bag.png' : '/pokedex.png'"
          :alt="collection.isWallet ? 'Sack of coins wallet' : 'Pokedex'"
          :title="`Collection type: ${
            collection.isWallet ? 'wallet' : 'custom'
          }`"
        />
      </div>
      <section class="description-section">
        <div
          class="info-line title nes-text"
          :class="collection?.name ? 'is-primary' : 'is-warning'"
        >
          <h4 class="m0">
            {{ collection?.name }}
            <h6
              :title="`Items in collection: ${collection.itemCount}`"
              class="nes-text is-disabled"
            >
              ({{ collection.itemCount || 0 }})
            </h6>
          </h4>
        </div>
        <div class="info-line description">
          <h6 v-html="collection?.note"></h6>
        </div>
        <div class="info-line description">
          <h6 v-html="collection?.wallet?.address"></h6>
        </div>

        <!-- <clipboard-container :content="collection.nftId" title="ID">
        {{ collection.nftId }}
      </clipboard-container> -->
      </section>
    </section>
    <section class="action-section flex-row full-width">
      <button
        title="Edit collection"
        @click="onEdit"
        class="action-btn nes-btn is-warning mx"
      >
        <img src="/edit.png" alt="edit" />
      </button>
      <button
        title="Add an nft to collection"
        @click="$emit('addNftToCollection', { collection, nft: {} })"
        class="action-btn nes-btn is-success"
      >
        &#43;
      </button>
    </section>
  </article>
</template>
<style lang="css" scoped>
h4,
h6 {
  display: inline-block;
  margin: 0;
}
.card {
  padding: 1rem;
  position: relative;
  max-width: 900px;
  min-width: 400px;
  width: 100%;
}

.info-icon {
  position: absolute;
  right: 1rem;
  top: 1rem;
  height: 1.25rem;
  width: 1.25rem;
}

.content-section {
  align-items: flex-start;
  justify-content: start;
  /* padding-block: 1rem; */
  /* height: 10rem; */
}

.image-container {
  /* height: 4rem; */
  width: clamp(4rem, 20vw, 6rem);
  min-width: 4rem;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}

.image-container img {
  height: auto;
  width: 100%;
}

img {
  /* max-height: 7rem;
  width: auto;
  max-width: 7rem; */
}

.description-section {
  padding-inline: 1rem;
}

.info-line {
  display: flex;
  align-content: flex-end;
  width: 100%;
}
.description {
  /* margin-top: 1rem; */
  max-height: 6rem;
  overflow-y: auto;
}

.action-section {
  display: flex;
  align-content: flex-end;
  justify-content: flex-end;
}
</style>
