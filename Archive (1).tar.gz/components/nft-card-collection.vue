<script>
import api from '@/services/api'
import wallet from '@/services/wallet'

import nftMixin from '@/mixins/nft-mixin.vue'

import ClipboardContainer from '@/components/clipboard-container.vue'
import ImageMissing from '@/components/image-missing.vue'
import NftPreview from '@/components/nft-preview.vue'
export default {
  name: 'nft-card-collection',
  props: {
    nft: {
      type: Object,
      required: true,
    },
  },
  components: {
    ClipboardContainer,
    ImageMissing,
    NftPreview,
  },
  mixins: [nftMixin],
  created() {
    console.log(this.nft)
  },
}
</script>

<template>
  <article
    class="card nes-container is-rounded is-dark nft flex-column full-width"
  >
    <img
      class="info-icon nes-avatar is-medium pointer"
      alt="button to display nft details modal"
      src="/info-box.png"
      @click="$emit('showDetails', nft)"
    />
    <section class="content-section full-width">
      <nft-preview :nft="nft"></nft-preview>
    </section>
    <section class="action-section flex-row full-width">
      <button
        title="Remove nft from collection"
        @click="$emit('removeNftFromCollection', nft)"
        class="action-btn nes-btn is-error mx"
      >
        &#45;
      </button>
      <button
        title="Add nft to another collection"
        @click="$emit('addNftToCollection', { nft })"
        class="action-btn nes-btn is-success"
      >
        &#43;
      </button>
    </section>
  </article>
</template>
<style lang="css" scoped>
.card {
  position: relative;
  max-width: 100%;
}

.info-icon {
  position: absolute;
  right: 1rem;
  top: 1rem;
  height: 2rem;
  width: 2rem;
}

.content-section {
  padding-right: 1.25rem;
  /* align-items: flex-start;
  justify-content: start; */
  /* padding-block: 1rem; */
}

.action-section {
  display: flex;
  align-content: flex-end;
  justify-content: flex-end;
  margin-top: auto;
  padding-top: 1rem;
}
</style>
