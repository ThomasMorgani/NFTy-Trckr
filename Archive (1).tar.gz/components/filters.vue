<script>
import { mapGetters, mapState } from 'vuex'

export default {
  name: 'filters',
  data: () => ({
    sortSelectOptions: [
      {
        disabled: false,
        hidden: false,
        text: 'Name Asc',
        value: 'name_asc',
      },
      {
        disabled: false,
        hidden: false,
        text: 'Name Desc',
        value: 'name_desc',
      },
      {
        disabled: false,
        hidden: false,
        text: 'Received Asc',
        value: 'received_asc',
      },
      {
        disabled: false,
        hidden: false,
        text: 'Received Desc',
        value: 'received_desc',
      },
    ],
  }),
  computed: {
    ...mapState({
      collectionsHeader: (state) => state.collectionsHeader,
      contentLoading: (state) => state.contentLoading,
      filters: (state) => state.filters,
      subView: (state) => state.subView,
      view: (state) => state.view,
    }),
    hasFilters() {
      return Object.values(this.filters).filter((f) => f).length > 0
    },
    searchInput: {
      get() {
        return this.filters.search
      },
      set(v) {
        this.$store.dispatch('setFilters', { ...this.filters, search: v })
      },
    },
    sortSelect: {
      get() {
        return this.filters.sortSelect
      },
      set(v) {
        this.$store.dispatch('setFilters', { ...this.filters, sortSelect: v })
      },
    },
  },
}
</script>

<template>
  <div class="filters-section full-width flex-row">
    <div class="filters-section-side">
      <label for="search-input">Search</label>
      <div class="nes-field">
        <input
          v-model="searchInput"
          type="text"
          id="search-input"
          class="nes-input is-dark"
        />
      </div>
    </div>
    <div class="filters-section-side">
      <label for="sort-select">Sort by</label>
      <div class="nes-select">
        <select required id="sort-select" v-model="sortSelect">
          <option
            v-for="option in sortSelectOptions"
            :key="option.value"
            :value="option.value"
            :disabled="option.disabled === true"
            :selected="option.value === sortSelect"
            :hidden="option.hidden"
          >
            {{ option.text }}
          </option>
        </select>
      </div>
    </div>
  </div>
</template>

<style scoped>
.filters-section {
  align-items: flex-start;
  justify-content: space-between;
  min-height: 120px;
}

.filters-section-side {
  width: 48%;
}
</style>
